import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.Qt import *

class MainWindow(QMainWindow):
    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
        self.setWindowTitle('Simple image editor')
        self.createMenu()
        self.createToolbar()

        self.imageContainer = QLabel(self)
        self.imageContainer.setAlignment(Qt.AlignCenter)
        self.imageContainer.setStyleSheet('background-image:url(background.jpg);')
        self.setCentralWidget(self.imageContainer)
        self.setFixedSize(640, 480)
        self.rawImage = QPixmap("lenna.jpg")
        self.image = self.rawImage

        self.rotateAngle = 0
        self.imageSize = QSize(300, 200)
        self.refreshImage()
        
    def createToolbar(self):
        zoomInAction = QAction(QIcon('zengjia.svg'), '放大', self)
        zoomInAction.triggered.connect(self.onZoomIn)
        zoomOutAction = QAction(QIcon('jianshao.svg'), '缩小', self)
        zoomOutAction.triggered.connect(self.onZoomOut)
        rotateAction = QAction(QIcon('shuaxin.svg'), '旋转', self)
        rotateAction.triggered.connect(self.onRotate)
        self.toolbar = self.addToolBar('Operations')
        self.toolbar.addAction(zoomInAction)
        self.toolbar.addAction(zoomOutAction)
        self.toolbar.addAction(rotateAction)

        slider = QSlider(Qt.Horizontal)
        slider.setFixedWidth(200)
        slider.setValue(100)
        slider.valueChanged.connect(self.onChangeBrightness)
        self.toolbar.addWidget(slider)

    def createMenu(self):
        menu = self.menuBar()
        menu.setNativeMenuBar(False)
        fileMenu = menu.addMenu('&文件')
        aboutMenu = menu.addMenu('&关于')

        fileAction = QAction('&打开', self)
        fileAction.setShortcut('Ctrl+O')
        fileAction.triggered.connect(self.onOpenFile)
        fileMenu.addAction(fileAction)

        aboutAction = QAction('&版本', self)
        aboutAction.setShortcut('Ctrl+A')
        aboutAction.triggered.connect(self.onAbout)
        aboutMenu.addAction(aboutAction)        
        return menu
    def onOpenFile(self):
        fileName, _ = QFileDialog.getOpenFileName(self, 'Choose image', '', 'Images(*.png, *.jpg')
        self.rawImage = QPixmap(fileName)
        self.image = self.rawImage
        self.refreshImage()
    def onZoomIn(self):
        self.imageSize *= 1.5
        self.refreshImage()
    def onZoomOut(self):
        self.imageSize *= 0.5
        self.refreshImage()
    def onRotate(self):
        newAngle = self.rotateAngle + 45
        if(newAngle > 360):
            newAngle = 0
        self.rotateAngle = newAngle
        self.refreshImage()
    def onChangeBrightness(self, value):
        image = self.rawImage.toImage()
        for i in range(0, image.width()):
            for j in range(0, image.height()):
                color = QColor(image.pixelColor(i, j))
                (h, s, l, a) = color.getHsl()
                newBrightless = l * (value/100.0)
                color.setHsl(h, s, newBrightless, a)
                image.setPixel(i, j, color.rgb())
        self.image = QPixmap.fromImage(image)
        self.refreshImage()
    def refreshImage(self):
        transform = QTransform()
        transform.rotate(self.rotateAngle)
        rotatedImage = self.image.transformed(transform)
        scaledImage = rotatedImage.scaled(self.imageSize.width(), self.imageSize.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.imageContainer.setPixmap(scaledImage)
    def onAbout(self):
        messageBox = QMessageBox(self)
        messageBox.setIcon(QMessageBox.Information)
        messageBox.setWindowTitle('About')
        messageBox.setText('Image editor version 1.0')
        messageBox.exec()
def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    app.exec_()

if __name__ == '__main__':
    main()